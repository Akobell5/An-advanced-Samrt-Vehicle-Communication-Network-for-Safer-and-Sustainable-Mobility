# ESP32-DC-Voltage-Measurement
Using an ESP32 to measure a range of DC voltages using a voltage divider add-on.

http://www.ohmslawcalculator.com/voltage-divider-calculator


